from django.apps import AppConfig


class PollsAPIConfig(AppConfig):
    name = 'pollsAPI'
