from django.apps import AppConfig


class SnippetsConfig(AppConfig):
    name = 'snippets'
